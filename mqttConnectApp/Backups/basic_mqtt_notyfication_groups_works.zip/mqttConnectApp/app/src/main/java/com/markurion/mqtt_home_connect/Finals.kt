package com.markurion.mqtt_home_connect

class Finals {
    companion object {
        const val brokerUrl = "tcp://broker.emqx.io:1883" // Replace with your broker URL
        const val clientId = "a00300334-mobile"
        const val MQTTServiceChannel_ID = "MQTTServiceChannel"
        const val topic = "a00300334/#" // Replace "your/topic" with your desired topic
    }
}